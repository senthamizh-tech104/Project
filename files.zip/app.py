"""
SkillSphere AI - AI-Powered Learning & Skill Development Platform
Single-file Flask backend.
"""

import os
import random
import string
from datetime import date
from functools import wraps

from dotenv import load_dotenv
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash, jsonify
)
from werkzeug.security import generate_password_hash, check_password_hash
import mysql.connector
from mysql.connector import Error as MySQLError

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this")

# ---------------------------------------------------------------------------
# Gemini setup
# ---------------------------------------------------------------------------
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
gemini_model = None
if GEMINI_API_KEY:
    try:
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)
        gemini_model = genai.GenerativeModel("gemini-1.5-flash")
    except Exception as e:
        print("Gemini setup failed:", e)
        gemini_model = None


def ask_gemini(prompt):
    """Send a prompt to Gemini and return plain text. Returns None on failure."""
    if not gemini_model:
        return None
    try:
        response = gemini_model.generate_content(prompt)
        return response.text
    except Exception as e:
        print("Gemini error:", e)
        return None


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------
def get_db():
    """Return a new MySQL connection or None if it fails."""
    try:
        conn = mysql.connector.connect(
            host=os.getenv("MYSQL_HOST", "localhost"),
            user=os.getenv("MYSQL_USER", "root"),
            password=os.getenv("MYSQL_PASSWORD", ""),
            database=os.getenv("MYSQL_DATABASE", "skillsphere"),
        )
        return conn
    except MySQLError as e:
        print("Database connection error:", e)
        return None


def run_query(query, params=None, fetch=False, fetchone=False, commit=False):
    """Small helper to run a query and always clean up the connection."""
    conn = get_db()
    if not conn:
        return None
    result = None
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params or ())
        if commit:
            conn.commit()
            result = cursor.lastrowid
        elif fetchone:
            result = cursor.fetchone()
        elif fetch:
            result = cursor.fetchall()
        cursor.close()
    except MySQLError as e:
        print("Query error:", e)
        result = None
    finally:
        conn.close()
    return result


# ---------------------------------------------------------------------------
# Auth decorators
# ---------------------------------------------------------------------------
def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                flash("Please log in to continue.", "warning")
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                flash("You are not authorized to perform this action.", "danger")
                return redirect(url_for("dashboard"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


DEFAULT_SKILLS = ["Python", "SQL", "AI", "Cloud"]


def seed_default_skills(user_id):
    for name in DEFAULT_SKILLS:
        run_query(
            "INSERT INTO skills (user_id, name, score) VALUES (%s, %s, %s)",
            (user_id, name, random.randint(30, 70)),
            commit=True,
        )


# ---------------------------------------------------------------------------
# Public routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "Learner")

        if not name or not email or not password:
            flash("All fields are required.", "danger")
            return redirect(url_for("register"))

        existing = run_query(
            "SELECT id FROM users WHERE email = %s", (email,), fetchone=True
        )
        if existing:
            flash("An account with this email already exists.", "danger")
            return redirect(url_for("register"))

        hashed = generate_password_hash(password)
        user_id = run_query(
            "INSERT INTO users (name, email, password, role) VALUES (%s, %s, %s, %s)",
            (name, email, hashed, role),
            commit=True,
        )
        if user_id is None:
            flash("Could not create account. Please try again.", "danger")
            return redirect(url_for("register"))

        seed_default_skills(user_id)
        flash("Account created successfully. Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("auth.html", mode="register")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = run_query(
            "SELECT * FROM users WHERE email = %s", (email,), fetchone=True
        )
        if not user or not check_password_hash(user["password"], password):
            flash("Invalid email or password.", "danger")
            return redirect(url_for("login"))

        session["user_id"] = user["id"]
        session["name"] = user["name"]
        session["role"] = user["role"]
        flash(f"Welcome back, {user['name']}!", "success")
        return redirect(url_for("dashboard"))

    return render_template("auth.html", mode="login")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    user_id = session["user_id"]

    active_courses = run_query(
        "SELECT COUNT(*) AS c FROM enrollments WHERE user_id = %s AND progress < 100",
        (user_id,), fetchone=True,
    ) or {"c": 0}

    certificates = run_query(
        "SELECT COUNT(*) AS c FROM certificates WHERE user_id = %s",
        (user_id,), fetchone=True,
    ) or {"c": 0}

    skills = run_query(
        "SELECT name, score FROM skills WHERE user_id = %s", (user_id,), fetch=True
    ) or []
    avg_score = round(sum(s["score"] for s in skills) / len(skills)) if skills else 0

    enrollments = run_query(
        """SELECT e.progress, c.title FROM enrollments e
           JOIN courses c ON e.course_id = c.id
           WHERE e.user_id = %s ORDER BY e.enrolled_at DESC LIMIT 6""",
        (user_id,), fetch=True,
    ) or []

    overall_progress = (
        round(sum(e["progress"] for e in enrollments) / len(enrollments))
        if enrollments else 0
    )

    assessments = run_query(
        "SELECT score, taken_at FROM assessments WHERE user_id = %s ORDER BY taken_at",
        (user_id,), fetch=True,
    ) or []

    return render_template(
        "dashboard.html",
        active_courses=active_courses["c"],
        certificates=certificates["c"],
        skill_score=avg_score,
        overall_progress=overall_progress,
        skills=skills,
        enrollments=enrollments,
        assessments=assessments,
    )


# ---------------------------------------------------------------------------
# Courses
# ---------------------------------------------------------------------------
@app.route("/courses")
@login_required
def courses():
    all_courses = run_query("SELECT * FROM courses ORDER BY created_at DESC", fetch=True) or []
    my_enrollments = run_query(
        "SELECT course_id, progress FROM enrollments WHERE user_id = %s",
        (session["user_id"],), fetch=True,
    ) or []
    enrolled_ids = {e["course_id"]: e["progress"] for e in my_enrollments}
    return render_template("courses.html", courses=all_courses, enrolled_ids=enrolled_ids)


@app.route("/course/create", methods=["POST"])
@roles_required("Admin", "Trainer")
def course_create():
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    ctype = request.form.get("type", "Video")
    duration = request.form.get("duration", "1 week")

    if not title:
        flash("Course title is required.", "danger")
        return redirect(url_for("courses"))

    run_query(
        "INSERT INTO courses (title, description, type, duration, created_by) VALUES (%s, %s, %s, %s, %s)",
        (title, description, ctype, duration, session["user_id"]),
        commit=True,
    )
    flash("Course created successfully.", "success")
    return redirect(url_for("courses"))


@app.route("/course/delete/<int:course_id>", methods=["POST"])
@roles_required("Admin", "Trainer")
def course_delete(course_id):
    course = run_query("SELECT id FROM courses WHERE id = %s", (course_id,), fetchone=True)
    if not course:
        flash("Course not found.", "danger")
        return redirect(url_for("courses"))

    run_query("DELETE FROM courses WHERE id = %s", (course_id,), commit=True)
    flash("Course deleted.", "info")
    return redirect(url_for("courses"))


@app.route("/course/enroll/<int:course_id>", methods=["POST"])
@login_required
def course_enroll(course_id):
    course = run_query("SELECT id FROM courses WHERE id = %s", (course_id,), fetchone=True)
    if not course:
        flash("Course not found.", "danger")
        return redirect(url_for("courses"))

    already = run_query(
        "SELECT id FROM enrollments WHERE user_id = %s AND course_id = %s",
        (session["user_id"], course_id), fetchone=True,
    )
    if already:
        flash("You are already enrolled in this course.", "info")
    else:
        run_query(
            "INSERT INTO enrollments (user_id, course_id, progress) VALUES (%s, %s, 0)",
            (session["user_id"], course_id), commit=True,
        )
        flash("Enrolled successfully!", "success")
    return redirect(url_for("courses"))


@app.route("/learn/<int:course_id>")
@login_required
def learn(course_id):
    course = run_query("SELECT * FROM courses WHERE id = %s", (course_id,), fetchone=True)
    if not course:
        flash("Course not found.", "danger")
        return redirect(url_for("courses"))

    enrollment = run_query(
        "SELECT * FROM enrollments WHERE user_id = %s AND course_id = %s",
        (session["user_id"], course_id), fetchone=True,
    )
    if not enrollment:
        run_query(
            "INSERT INTO enrollments (user_id, course_id, progress) VALUES (%s, %s, 0)",
            (session["user_id"], course_id), commit=True,
        )
        enrollment = {"progress": 0}

    return render_template("learning.html", course=course, enrollment=enrollment)


@app.route("/learn/<int:course_id>/complete", methods=["POST"])
@login_required
def learn_complete(course_id):
    run_query(
        "UPDATE enrollments SET progress = 100 WHERE user_id = %s AND course_id = %s",
        (session["user_id"], course_id), commit=True,
    )

    existing_cert = run_query(
        "SELECT id FROM certificates WHERE user_id = %s AND course_id = %s",
        (session["user_id"], course_id), fetchone=True,
    )
    if not existing_cert:
        cert_id = "SSA-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
        run_query(
            "INSERT INTO certificates (user_id, course_id, certificate_id, date) VALUES (%s, %s, %s, %s)",
            (session["user_id"], course_id, cert_id, date.today()), commit=True,
        )
        flash("Course completed! Certificate issued.", "success")
    else:
        flash("Course marked as complete.", "success")

    return redirect(url_for("learn", course_id=course_id))


# ---------------------------------------------------------------------------
# Assessment
# ---------------------------------------------------------------------------
QUIZ_QUESTIONS = [
    {
        "question": "Which keyword is used to define a function in Python?",
        "options": ["func", "def", "function", "lambda"],
        "answer": "def",
    },
    {
        "question": "Which SQL clause is used to filter rows?",
        "options": ["ORDER BY", "GROUP BY", "WHERE", "SELECT"],
        "answer": "WHERE",
    },
    {
        "question": "Which of these is a supervised learning algorithm?",
        "options": ["K-Means", "Linear Regression", "PCA", "Apriori"],
        "answer": "Linear Regression",
    },
    {
        "question": "What does 'API' stand for?",
        "options": [
            "Application Programming Interface",
            "Automated Program Instruction",
            "Application Process Integration",
            "Advanced Programming Index",
        ],
        "answer": "Application Programming Interface",
    },
    {
        "question": "Which cloud service model provides raw virtual machines?",
        "options": ["SaaS", "PaaS", "IaaS", "FaaS"],
        "answer": "IaaS",
    },
]


@app.route("/assessment", methods=["GET", "POST"])
@login_required
def assessment():
    if request.method == "POST":
        score = 0
        for i, q in enumerate(QUIZ_QUESTIONS):
            selected = request.form.get(f"q{i}")
            if selected == q["answer"]:
                score += 1

        percentage = round((score / len(QUIZ_QUESTIONS)) * 100)
        result = "Passed" if percentage >= 50 else "Failed"

        run_query(
            "INSERT INTO assessments (user_id, score) VALUES (%s, %s)",
            (session["user_id"], score), commit=True,
        )

        return render_template(
            "assessment.html",
            questions=QUIZ_QUESTIONS,
            submitted=True,
            score=score,
            total=len(QUIZ_QUESTIONS),
            percentage=percentage,
            result=result,
        )

    return render_template("assessment.html", questions=QUIZ_QUESTIONS, submitted=False)


# ---------------------------------------------------------------------------
# Skills
# ---------------------------------------------------------------------------
@app.route("/skills")
@login_required
def skills():
    user_skills = run_query(
        "SELECT name, score FROM skills WHERE user_id = %s", (session["user_id"],), fetch=True
    ) or []
    return render_template("skills.html", skills=user_skills)


@app.route("/skills/analyze", methods=["POST"])
@login_required
def skills_analyze():
    data = request.get_json(silent=True) or {}
    current_skills = data.get("current_skills", "").strip()
    required_skills = data.get("required_skills", "").strip()

    if not current_skills or not required_skills:
        return jsonify({"error": "Please provide both current and required skills."}), 400

    prompt = f"""You are a skill gap analysis assistant for a learning platform.
Current skills of the learner: {current_skills}
Required skills for the target role: {required_skills}

Respond ONLY in plain text using exactly this structure (no markdown symbols):
Missing Skills: <comma separated list>
Recommended Courses: <comma separated list>
Learning Path: <short numbered plan in 3-5 steps, separated by semicolons>
"""

    reply = ask_gemini(prompt)
    if reply is None:
        return jsonify({
            "fallback": True,
            "missing_skills": "Unable to reach AI service right now.",
            "recommended_courses": "Please check back later or explore the Courses page.",
            "learning_path": "1. Review current skills; 2. Pick a related course; 3. Practice with a project.",
        })

    missing, recommended, path = "Not specified", "Not specified", "Not specified"
    for line in reply.splitlines():
        line = line.strip()
        if line.lower().startswith("missing skills"):
            missing = line.split(":", 1)[-1].strip()
        elif line.lower().startswith("recommended courses"):
            recommended = line.split(":", 1)[-1].strip()
        elif line.lower().startswith("learning path"):
            path = line.split(":", 1)[-1].strip()

    return jsonify({
        "fallback": False,
        "missing_skills": missing,
        "recommended_courses": recommended,
        "learning_path": path,
    })


# ---------------------------------------------------------------------------
# AI Mentor
# ---------------------------------------------------------------------------
@app.route("/mentor")
@login_required
def mentor():
    return render_template("mentor.html", gemini_configured=bool(gemini_model))


@app.route("/mentor/ask", methods=["POST"])
@login_required
def mentor_ask():
    if not gemini_model:
        return jsonify({"reply": "Gemini AI is not configured."})

    data = request.get_json(silent=True) or {}
    question = data.get("question", "").strip()
    if not question:
        return jsonify({"reply": "Please ask a question."})

    prompt = f"You are a friendly, encouraging AI learning mentor on a platform called SkillSphere AI. Answer concisely and helpfully.\n\nStudent question: {question}"
    reply = ask_gemini(prompt)
    if reply is None:
        reply = "Sorry, I couldn't process that right now. Please try again in a moment."

    return jsonify({"reply": reply})


# ---------------------------------------------------------------------------
# Knowledge Hub
# ---------------------------------------------------------------------------
@app.route("/hub", methods=["GET", "POST"])
@login_required
def hub():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()
        if title and content:
            run_query(
                "INSERT INTO discussions (user_id, title, content) VALUES (%s, %s, %s)",
                (session["user_id"], title, content), commit=True,
            )
            flash("Discussion posted.", "success")
        else:
            flash("Title and content are required.", "danger")
        return redirect(url_for("hub"))

    discussions = run_query(
        """SELECT d.*, u.name AS author FROM discussions d
           JOIN users u ON d.user_id = u.id
           ORDER BY d.created_at DESC""",
        fetch=True,
    ) or []
    return render_template("hub.html", discussions=discussions)


# ---------------------------------------------------------------------------
# Profile
# ---------------------------------------------------------------------------
@app.route("/profile")
@login_required
def profile():
    user = run_query("SELECT * FROM users WHERE id = %s", (session["user_id"],), fetchone=True)

    skills_data = run_query(
        "SELECT name, score FROM skills WHERE user_id = %s", (session["user_id"],), fetch=True
    ) or []
    avg_score = round(sum(s["score"] for s in skills_data) / len(skills_data)) if skills_data else 0

    completed = run_query(
        "SELECT COUNT(*) AS c FROM enrollments WHERE user_id = %s AND progress = 100",
        (session["user_id"],), fetchone=True,
    ) or {"c": 0}

    certificates = run_query(
        """SELECT cert.certificate_id, cert.date, c.title AS course_title
           FROM certificates cert JOIN courses c ON cert.course_id = c.id
           WHERE cert.user_id = %s ORDER BY cert.date DESC""",
        (session["user_id"],), fetch=True,
    ) or []

    return render_template(
        "profile.html",
        user=user,
        skill_score=avg_score,
        completed_courses=completed["c"],
        certificates=certificates,
    )


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------
@app.errorhandler(404)
def not_found(e):
    flash("Page not found.", "warning")
    return redirect(url_for("index"))


@app.errorhandler(500)
def server_error(e):
    flash("Something went wrong on our end. Please try again.", "danger")
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
